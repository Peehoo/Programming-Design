Name: Peehoo Dewan
USC loginid: pdewan
CS 455 PA1
Fall 2013

----------------------------------------------
CERTIFY IT'S YOUR WORK

"I certify that the work submitted for this assignment does not
violate USC's student conduct code.  In particular, the work is my
own, not a collaboration, and does not involve code created by other
people, except for the the resources explicitly mentioned in the CS 455
Course Syllabus.  And I did not share my solution or parts of it with
other students in the course."

Initial below to "sign" the above statement:

PD
----------------------------------------------
ACKNOWLEDGE ANY OUTSIDE SOURCES

List here any code you submitted for this assignment that was written
with significant help of a course staff member, or code used from the
textbook.  Be specific about what methods or algorithms are involved,
and what sections of the textbook are involved (if applicable): [you do
not need to list any of the code that we wrote for the assignment,
i.e., the contents of the starter files for the assignment]

I have used information from section 2.9 and 2.10 from Big Java Early Objects 5th edition
for drawing the frame and lines.
----------------------------------------------
KNOWN BUGS or LIMITATIONS:


There is no error handling for negative step size
----------------------------------------------
ANY OTHER NOTES FOR THE GRADER:

None

----------------------------------------------
ANSWERS TO ASSIGNMENT README QUESTIONS (if applicable):

1. As all the four directions are equally likely to occur so the drunkard can end up at the same
point where he started and therefore there are so many deadends.

2,3 When I minimize and maximize the frame, nothing changes in the frame. It might gets redrawn but
there is no visible effect that I can notice. Also I am running it on Mac.

