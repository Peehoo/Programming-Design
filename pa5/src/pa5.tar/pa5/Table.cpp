// Table.cpp  Table class implementation
// CSCI 455 PA5
// Name:
// Loginid:

/*
 * Modified 11/22/11 by CMB
 *   changed name of constructor formal parameter to match .h file
 */

#include "Table.h"

#include <iostream>
#include <string>
#include <cassert>

//*************************************************************************
// Node class definition and member functions
//     You don't need to add or change anything in this section

// Note: we define the Node in the implementation file, because it's only
// used by the Table class; not by any Table client code.

struct Node {
  string key;
  int value;

  Node *next;

  Node(const string &theKey, int theValue);

  Node(const string &theKey, int theValue, Node *n);
};

Node::Node(const string &theKey, int theValue) {
  key = theKey;
  value = theValue;
  next = NULL;
}

Node::Node(const string &theKey, int theValue, Node *n) {
  key = theKey;
  value = theValue;
  next = n;
}

typedef Node * ListType;

//*************************************************************************


Table::Table() {

}


Table::Table(unsigned int hSize) {

}


int * Table::lookup(const string &key) {
  return NULL;   // dummy return value for stub
}

bool Table::remove(const string &key) {
  return false;  // dummy return value for stub
}

bool Table::insert(const string &key, int value) {
  return false;  // dummy return value for stub
}

int Table::numEntries() const {
  return 0;      // dummy return value for stub
}


void Table::printAll() const {

}

void Table::hashStats(ostream &out) const {
  
}


// add definitions for your private methods here
